<?php


date_default_timezone_set("Asia/Shanghai");
class Database
{
    protected $pdo;
    private $dsn = "mysql:dbname=test;host=localhost";
    private $username = "root";
    private $password = "";

    /**
     * Database constructor.
     *
     * @param string $dsn The DSN string.
     * @param string $username The username to connect to the database.
     * @param string $password The password to connect to the database.
     * @param array $options An array of PDO options.
     */
    public function __construct(array $options = [PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC])
    {
        $dsn = $this->dsn;
        $username = $this->username;
        $password = $this->password;
        $this->pdo = new PDO($dsn, $username, $password, $options);
    }

    /**
     * Executes a SQL query and returns the result set as an array of objects.
     *
     * @param string $query The SQL query to execute.
     * @param array $params An array of parameters to bind to the query.
     * @return array An array of objects representing the rows returned by the query.
     */
    public function query(string $query, array $params = []): array
    {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }




    /**
     * Executes a SQL query and returns the first row as an object.
     *
     * @param string $query The SQL query to execute.
     * @param array $params An array of parameters to bind to the query.
     * @return object|null The first row returned by the query, or null if no rows were returned.
     */
    public function queryOne(string $query, array $params = []): ?object
    {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetch(PDO::FETCH_OBJ) ?: null;
    }

    /**
     * Executes a SQL query and returns the value of the first column of the first row.
     *
     * @param string $query The SQL query to execute.
     * @param array $params An array of parameters to bind to the query.
     * @return mixed The value of the first column of the first row returned by the query.
     */
    public function queryScalar(string $query, array $params = [])
    {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->fetchColumn();
    }

    /**
     * Executes a SQL query and returns the number of rows affected.
     *
     * @param string $query The SQL query to execute.
     * @param array $params An array of parameters to bind to the query.
     * @return int The number of rows affected by the query.
     */
    public function execute(string $query, array $params = []): int
    {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount();
    }

    /**
     * Begins a transaction.
     */
    public function beginTransaction()
    {
        $this->pdo->beginTransaction();
    }

    /**
     * Commits a transaction.
     */
    public function commit()
    {
        $this->pdo->commit();
    }

    /**
     * Rolls back a transaction.
     */
    public function rollBack()
    {
        $this->pdo->rollBack();
    }
}



class Cron
{
    private array $nextDrawData;
    private array $nextTwoDraws;
    private $conn;
    private $timerTable;
    private int $defaultInterval; //seconds
    private const GAP_INTERVAL = 3600; // seconds
    private const TOTAL_RANDOM_NUMBERS = 5;
    private const GAME_START = "00:00:00";
    private const GAME_END = "24:00:00";
    private const GAP_START = "04:59:00"; //1 hour gap
    private const GAP_END = "06:00:00";
    private array $insertTables;
    private array $dataToSend;


    public function __construct($timerTable, $insertTables, $defaultInterval)
    {
        $this->insertTables = $insertTables;
        $this->defaultInterval = $defaultInterval;
        $this->timerTable = $timerTable;
        $this->conn = new Database();
        $this->setNextDrawData();
        // echo $this->getNextTwoDrawsSecs();
    }


    function generateRandomNumbers($total = 5, $min = 0, $max = 9)
    {
        $result = [];
        for ($i = 0; $i < $total; $i++)
            array_push($result, random_int($min, $max));
        return $result;
    }

    function getRandomNumbers($type)
    {
        $randomNumbers = "0,0,0,0,0,0,0,0,0,0,0";
        switch ($type) {
            case '5d':
                $randomNumbers = $this->getRand_5d();
                break;
            case '3d':
                $randomNumbers = $this->getRand_3d();
                break;
            case '49x7':
                $randomNumbers = $this->getRand_49x7();
                break;
            case '11x5':
                $randomNumbers = $this->getRand_11x5();
                break;
            case 'pk_10':
                $randomNumbers = $this->getRand_pk10();
                break;
            case 'fast_3':
                $randomNumbers = $this->getRand_fast3();
                break;
            case 'pc_28':
                $randomNumbers = $this->getRand_pc28();
                break;
        }
        return $randomNumbers;
    }


    function getRand_5d()
    {
        $number = str_shuffle(rand(00000, 99999));
        $length = 5;
        $string = substr(str_repeat(0, $length) . $number, -$length);
        $this->str_drawNumber = sprintf("%05d", $string);
        $numArr = str_split($this->str_drawNumber);
        $drawNumber = implode(",", $numArr);
        return $drawNumber;
    }

    function getRand_fast3()
    {
        $ArrNumber = array("1", "2", "3", "4", "5", "6");
        shuffle($ArrNumber);
        $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2];
        return $drawNumber;
    }

    function getRand_pc28()
    {
        $number = str_shuffle(rand(000, 999));
        $length = 3;
        $string = substr(str_repeat(0, $length) . $number, -$length);
        $this->str_drawNumber = sprintf("%03d", $string);
        $numArr = str_split($this->str_drawNumber);
        $drawNumber = implode(",", $numArr);
        return $drawNumber;
    }

    function getRand_3d()
    {
        $number = str_shuffle(rand(000, 999));
        $length = 3;
        $string = substr(str_repeat(0, $length) . $number, -$length);
        $this->str_drawNumber = sprintf("%03d", $string);
        $numArr = str_split($this->str_drawNumber);
        $drawNumber = implode(",", $numArr);
        return $drawNumber;
    }

    function getRand_pk10()
    {
        $ArrNumber = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "10");
        shuffle($ArrNumber);
        $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6] . "," . $ArrNumber[7] . "," . $ArrNumber[8] . "," . $ArrNumber[9];
        return $drawNumber;
    }

    function getRand_11x5()
    {
        $ArrNumber = array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11");
        shuffle($ArrNumber);
        $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4];
        return $drawNumber;
    }

    function getRand_49x7()
    {
        $ArrNumber = array("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49");
        shuffle($ArrNumber);
        $drawNumber = $ArrNumber[0] . "," . $ArrNumber[1] . "," . $ArrNumber[2] . "," . $ArrNumber[3] . "," . $ArrNumber[4] . "," . $ArrNumber[5] . "," . $ArrNumber[6];
        return $drawNumber;
    }



    /**
     * the number of seconds between 12 am today and the @$time provided
     *
     * @param string $time the time to calculate the number of seconds up to.
     * @param string $start where to start calculating difference. default is 12 am today
     * @return string the difference in seconds
     */
    function getSecondsElapsed($time, $start = "today")
    {
        $dateTime = DateTime::createFromFormat("H:i:s", $time);
        $timeElapsed = $dateTime->getTimestamp() - strtotime($start);
        return $timeElapsed;
    }

    /**
     * gets the next draw datetime that comes immediately after the "$time" provided
     *
     * @param string  $time the datetime or time to start calculating from.
     * @return string the next closest draw datetime to the "$time" provided
     */
    function getNextDrawTime($time)
    {
        $time = Date("H:i:s", strtotime($time));
        //if the time requested is still between the gap ie if gap hasn't ended.
        if (($this::GAP_START and $this::GAP_END) and $time >= $this::GAP_START and $time < $this::GAP_END) {
            return date("Y-m-d") . ' ' . $this::GAP_END;
        }

        //if the last data has been drawn
        if ($time >=  $this::GAME_END) {
            $nextDay = strtotime("+$this->defaultInterval seconds", strtotime($this::GAME_END));
            return date("Y-m-d", $nextDay) . ' ' . $this::GAME_START;
        }

        //round the time up to the nearest draw time
        $timeElapsed = $this->getSecondsElapsed($time, $this::GAME_START);
        $surplusSeconds = $timeElapsed % $this->defaultInterval;
        $nextDrawInSecs = $timeElapsed - $surplusSeconds + $this->defaultInterval;
        $nextDrawTimestamp = $nextDrawInSecs + strtotime($this::GAME_START);
        return date("Y-m-d H:i:s", $nextDrawTimestamp);
    }

    /**
     * sets the information about the next draw. 
     * information is in an array with keys draw_count and draw_time
     *
     * @return void
     */
    public function setNextDrawData()
    {
        $currentTime = Date('H:i:s');
        $this->dataToSend["requestTime"] = $currentTime;
        $aboutToDrawDatetime = $this->getNextDrawTime($currentTime); //gets next draw time based on current time.
        $this->dataToSend["aboutToDrawDatetime"] = $aboutToDrawDatetime;
        $aboutToDrawData = explode(" ", $aboutToDrawDatetime);
        $aboutToDrawHIS = $aboutToDrawData[1];
        $SQL = "SELECT count AS draw_count,  timeset AS draw_time FROM $this->timerTable WHERE timeset = ? LIMIT 1";
        $results = $this->conn->query($SQL, [$aboutToDrawHIS]);
        $this->dataToSend["SQL_Results"] = $results;
        $nextDraw = $results[0];
        $nextDraw["draw_time"] = explode(' ', $aboutToDrawDatetime)[1];
        $nextDraw['draw_date'] = Date('Ymd') . str_pad($nextDraw['draw_count'],  4, "0", STR_PAD_LEFT);
        $nextDraw["aboutToDrawTime"] = $aboutToDrawDatetime;
        $drawInfo = [];
        foreach ($this->insertTables as $table => $algo) {
            $drawInfo[$table] = $this->getRandomNumbers($algo);
        }
        $nextDraw['drawInfo'] = $drawInfo;
        $this->dataToSend["dataInserted"] = $nextDraw;
        $this->nextDrawData = $nextDraw;
    }

    /**
     * gets the difference between the current draw and the next draw after that.
     *
     * @return void
     */
    public function getNextTwoDrawsSecs()
    {
        $nextDrawTime = $this->getNextDrawTime($this->nextDrawData['draw_time']);
        $justDrawTime = $this->nextDrawData['draw_time'];
        return $this->getDifferenceInSecs($nextDrawTime, $justDrawTime);
    }



    /**
     * inserts the current draw details into the database
     *@param string $table the table to insert the draw details into
     *@param string $drawNumbers the random drawn numbers.
     * @return void
     */
    public function insertDrawDetails($table, $drawNumbers)
    {
        $gameId = explode('_', $table)[1];
        $command = 'start';
        $notify = 'hide';
        $draw_date = $this->nextDrawData['draw_date'];
        $date_created = date("Y-m-d");
        $SQL = "SELECT COUNT(draw_date) FROM $table WHERE draw_date = ?";
        $SQL2 = "SELECT COUNT(game_id) FROM games WHERE command = ? AND notify = ? AND game_id = ?";
        // $SQL = "SELECT COUNT(draw_date) FROM $table WHERE draw_date = ?";
        $canInsert = $this->conn->queryScalar($SQL2, [$command, $notify, $gameId]);
        $dataExists = $this->conn->queryScalar($SQL, [$draw_date]);
        if (!$dataExists && $canInsert) {
            $SQL = "INSERT INTO $table(draw_date, draw_time, draw_number, draw_count, date_created, get_time) VALUES (?, ?, ?, ?, ?, ?)";
            $draw_time =  $this->nextDrawData['draw_time'];
            $draw_count = $this->nextDrawData['draw_count'];
            $draw_datetime = Date('H:i:s');
            // echo json_encode([$draw_id, $draw_date, $draw_numbers, $draw_datetime]);
            // die;
            $this->conn->query($SQL, [$draw_date, $draw_time, $drawNumbers, $draw_count,  $date_created, $draw_datetime]);
        } else {
            $this->dataToSend["requestStatus"] = "not inserted";
        }
    }

    /**
     * gets the number of seconds between two dates.
     * this function only works if the difference in dates does not exceed 30 days;
     *
     * @param string $time1 the first date time
     * @param mixed $time2 the second date time. if this isn't provided, current datetime will be used.
     * @return int the number of seconds between the two dates provided.
     */
    public function getDifferenceInSecs($time1, $time2 = true)
    {
        $start = new DateTime($time1);
        $end = $time2 === true ? new DateTime() : new DateTime($time2);
        $diff = $start->diff($end);
        $diffInSecs = $diff->d * 24 * 60 * 60 + $diff->h * 60 * 60 + $diff->i * 60 + $diff->s;
        return $diffInSecs;
    }


    /**
     * gets the seconds before the next draw
     *
     * @return int
     */
    public  function getSecondsUntilNextDraw()
    {
        return $this->getDifferenceInSecs($this->nextDrawData["aboutToDrawTime"]);
    }


    function startCron()
    {
        $delay = $this->getSecondsUntilNextDraw();
        $this->dataToSend["delay"] = $delay;
        $response["nextRequestTime"] = $this->getSecondsUntilNextDraw();

        //if waiting time is more than 1 minute then send data to client telling when to make the next request.
        if ($delay <= 60) {
            sleep($delay);
            foreach ($this->nextDrawData['drawInfo'] as $table => $drawNumbers) {
                $this->insertDrawDetails($table, $drawNumbers);
            }
            $response["nextRequestTime"] = $this->getNextTwoDrawsSecs();
        }
        $response["logs"] = $this->dataToSend;
        $response["check"] = $this->nextDrawData['draw_time'];
        echo json_encode($response);
        die;
    }
}

